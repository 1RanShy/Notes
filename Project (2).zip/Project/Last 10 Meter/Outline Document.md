![Example](assets/Example%201.doc)

![报告](assets/2633609R_Ran_ENG5059P_Prelim_23%201.doc)
- [ ] Risk assesment怎么写
- [ ] 前面的表格填写的对不对
- [ ] 甘特图画好
- [ ] 发给老师看看 早上九点之前




**Introduction (max 1 page)**

**Aims/Objectives of project**

**Resources required**

**GANTT chart**

**Risk assessment**
