#include "LED.h"

void serialPrint::printx()
{

  Serial.println("Helo World");
}