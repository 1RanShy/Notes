/*******************
LED.h

*******************/

#ifndef _LED_H__
#define _LED_H__

// 导入Arduino核心头文件
#include "Arduino.h"

class serialPrint
{
public:
  void printx();
};

#endif
